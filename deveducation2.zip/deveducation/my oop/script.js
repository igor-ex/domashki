function ex(val, comment) {
    comment = typeof comment !== 'undefined' ? comment + ' =' : '';
    return console.log(comment, val);
}

function Person(age) {
    const versions = [];

    function saveAge (age) {
        versions.push(age);
    }

    this.setAge = function (newAge) {
        age = newAge;
        saveAge(newAge);
    }

    this.getAge = function () {
        return age;
    }

    this.getVersions = function() {
        return versions.slice();
    }

    if (typeof age !== undefined) {
        saveAge(age);
    }
}

var child = new Person(1);
ex(child.getAge(), 'age 1');
child.setAge(2);
child.setAge(5);
ex(child.getAge(), 'age 2');
ex(child.getVersions(), 'age changes')

function PersonGendered (age, gender) {
    Person.apply(this, [age]);

    this.getGender = function () {
        return gender;
    }
    const parentSetAge = this.setAge.bind(this);
    this.setAge = function (age) {
        parentSetAge(age);
        console.log('-- now the age is stored in the safe place --');
    }
}
ex('girl:')
var girl = new PersonGendered(3, 'female');
girl.setAge(7);
ex(girl.getAge(), 'girl\'s age');
ex(girl.getGender());
ex(girl.getVersions(), 'age changes')
ex(child.getVersions(), 'childs ages')