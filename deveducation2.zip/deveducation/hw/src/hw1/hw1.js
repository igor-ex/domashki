function multiplyOrSum(a, b) {
    
}