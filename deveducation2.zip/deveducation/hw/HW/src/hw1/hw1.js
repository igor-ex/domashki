function multiplyOrSum(a, b) {
    if (a % 2 === 0) {
        return a * b;
    }

    return a + b;
}

function getQuarterByCoordinates(x, y) {
    if (x > 0 && y > 0) {
        return 1;
    } else if (x < 0 && y > 0) {
        return 2;
    } else {
        throw Error('kkkkk');
    }
}

function getPositiveNumbers(a, b, c) {
    let result = 0;

    if (a > 0) {
        result += a;
    }

    if (b > 0) {
        result += b;
    }

    if (c > 0) {

    }
}

function getMinArrEl(arr){
    if(!arr.length)
        return null;
    var min = arr[0];
    for(var i=0; i<arr.length; i++){
        if(arr[i]<min)
            min = arr[i];
    }
    return min;
}
