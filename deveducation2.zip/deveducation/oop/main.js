//инкапсуляция

function ex(val, comment) {
    comment = typeof comment !== 'undefined' ? comment + ' =' : '';
    return console.log(comment, val);
}

function ProgrammerF(age, name) {
    this.age = null;
    this.name = null;
    const CONSTANT_TD = 1;



    this.toString = function() {
        console.log(age, name, CONSTANT_TD);
    }
    function incapsulated() {

    }

    //incapsulated().call(this)//получить данные к this.переменным

    const fu = function() {

    }.bind(this);//привязывает контекст к функции сразу. bind возвращает новую функцию
    //можно использовать стрелочные функции, они как this используют объект в котором была создана фун
    //то есть функция Programmer
}



function Programmer(age, name) {
    this.age = age;
    this.name = name;
    const CONSTANT_TD = 1;
    this.toString = function () {
        return age + ' ' + CONSTANT_TD;
    }
    this.getName = function () {
        return age + ' ' + CONSTANT_TD;
    }
    this.setAge = function (value) {
        this.age = value;
    }
}

function JuniorProgrammer(age, name)
{
    Programmer.call(this, [age, name])//наследование
    this.level = 'junior'
    this.toString = function () {
        return this.age + ' ' + this.name + ' ' + this.level;
    }
    const parrentSetAge = this.setAge.bind(this);
    this.setAge = function (value) {
        parrentSetAge(value)
        this.age = this.age + 5;
    }
}

JuniorProgrammer.prototype = Object.create(Programmer.prototype)//наследование прототипное
JuniorProgrammer.prototype.constructor = JuniorProgrammer;//защита от багов

function Programmer(age, name) {
    Programmer.apply(this, arguments)
    this.age = age;
    this.name = name;
    const _CONSTANT_TD= 1;//для програмеров
}
Programmer.prototype.toString = function () {
    Programmer.prototype.setAge.apply(this, [value])//расширить функционал
    return this.age + ' ' + ' ' + this.CO;//работать только с this
}

function Prog(name) {
    this.set = function (val) {
        this.name = val;
    }
    function g() {
        return this.name;
    }
    this.get = function () {
        return g.call(this);
    }
}
var a = new Prog('Steve')
ex(a.get())
ex(a)
a.set('Stas')
ex(a.get())

function User(name) {

    this.sayHi = function() {
        alert( "Привет, я " + name );
    };

}


var vasya = new User("Вася"); // создали пользователя
vasya.sayHi(); // пользователь умеет говорить "Привет"