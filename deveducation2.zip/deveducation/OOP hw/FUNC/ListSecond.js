function ListSecond() {
    ListFirst.apply(this);

    this.sort = function() {};

    this.toString = function () {};

    this.toArrayList = function () {};

    this.toLinkedList = function () {};
}