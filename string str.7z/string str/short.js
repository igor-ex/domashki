function sgetShortesStringlength(str) {
    return (str.match(/[\s,.:;()?!"\\/#$%\]\]^&*{}=\-+_`~<>]+/g) || ['']).reduce((acc, val) => val.length < acc.length ? val : acc).length;
}
function schangeDollar(arr, len) {
    return arr.map(val => val.length === len && val.length >= 3 ? val.slice(0, - 3) + '$' : val);
}
function saddSpacesAfterPunctuation(s) {
    return s.replace(/([,.:;)?!"]+)([^\s,.:;()?!"]{1})/g, '$1 $2');
}
function skeepOneUniqueSymbolInTheString (s) {
    return Array.from(new Set(s.split(''))).join('');
}
function scountWords(str) {
    return (str.match(/[^\s,.:;()?!"]+/g) || []).length;
}
function sstrSplice (s, start, length) {
    return s.slice(0, start) + s.slice(start + length);
}
function sreverseString(str) {
    return str.split('').reverse().join();
}
function sdeleteString(str) {
    return str.replace(/[^\s,.:;()?!"]+([\s,.:;()?!"]*)$/, '$1');
}