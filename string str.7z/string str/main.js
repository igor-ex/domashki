
// 1) Вывести в одну строку символы:
//     1. английского алфавита от ‘A’ до ‘Z’
function getEngAlphabetUpperCase() {
    var res = '';
    for (var i = 65; i <= 90; i++) {
        res += String.fromCharCode(i);
    }
    return res;
}

//2. английского алфавита от ‘z’ до ‘a’
function getEngAlphabetLowCaseReverse() {
    var res = '';
    for (var i = 122; i >= 97; i--) {
        res += String.fromCharCode(i);
    }
    return res;
}

//3. русского алфавита от ‘а’ до ‘я’
function getRusAlphabetUpperCase() {
    var res = '';
    for (var i = 1072; i < 1104; i++) {
        res += String.fromCharCode(i);
    }
    return res;
}

//4. цифры от ‘0’ до ‘9’
function getASCIINmbers() {
    var res = '';
    for (var i = 48; i < 58; i++) {
        res += String.fromCharCode(i);
    }
    return res;
}

//5. печатного диапазона таблицы ASCII
function getASCIIPrintsSimbals() {
    var res = '';
    for (var i = 32; i < 127; i++) {
        res += String.fromCharCode(i);
    }
    return res;
}

//2) Написать и протестировать функции преобразования:
//1. целого числа в строку
function parseIntNumberToString(digit){
    let stringDigit = ''+parseInt(digit);
    return stringDigit;
}

//2)2.вещественного числа в строку
function parseFloatNumberToString(digit){
    let stringDigit = ''+parseFloat(digit);
    return stringDigit;
}

//2)3.строки в целое число
function parseStringToIntNumber(strDigit){
    let digit = parseInt(+strDigit);
    return digit;
}

//3)4.строки в вещественное число
function parseStringToFloatNumber(strDigit){
    let digit = parseFloat(+strDigit);
    return digit;
}

//3) Написать и протестировать функции работы со строками:
    //3)1. Дана строка, состоящая из слов, разделенных пробелами и знаками препинания. Определить длину самого короткого слова
function getShortestWordLenRegex(str) {
    if (str === '') {
        return 0;
    }
    var arr =  str.trim().split(/[ ,\.;\?!]+/);
    if (arr.length < 1) {
        return 0;
    }
    var tmp = '';
    for (var i = 0; i < arr.length; i++) {
        if (arr[i] === '') {
            continue;
        }
        if (arr[i].length < tmp.length || tmp === '') {
            tmp = arr[i];
        }
    }
    return tmp.length ? tmp.length : null;
}

function getShortestWordLen(str) {
    if (str === '') {
        return 0;
    }
    var arr =  splitWordsBySymbols(str);
    if (arr.length < 1) {
        return 0;
    }
    var tmp = arr[0];
    for (var i = 0; i < arr.length; i++) {
        if (arr[i].length < tmp.length) {
            tmp = arr[i];
        }
    }
    return tmp.length;
    function splitWordsBySymbols(s) {//разделяет строку по знакам препинания и пробелам
        var ref = '!.,;? ';
        var buffer = '';
        var res = [];
        for (var i = 0; i < s.length; i++) {
            if (ref.indexOf(s[i]) === -1) {//наш символ не разделитель
                buffer += s[i];//отправили символ в буффер
            } else {
                if (buffer !== '') {
                    res.push(buffer);
                    buffer = '';
                }
            }
        }
        if (buffer !== '') {
            res.push(buffer);
        }
        return res;
    }
}

//3)2. Дан массив слов. Заменить последние три символа слов, имеющих заданную длину на символ $
function replaceLastThreeSymbols(arr, len) {
    for(var i = 0; i < arr.length; i++){
        if(arr[i].length === len){
            arr[i] = arr[i].slice(0, - 3) + '$';
        }
    }
    return arr;
}

//3)3.Добавить в строку пробелы после знаков препинания, если они там отсутствуют.
function enterSpaces(s) {
    var ref = '!.,:;?';
    var res = '';
    for (var i = 0; i < s.length; i++) {
        res += s[i];
        if (ref.indexOf(s[i]) > -1) {//наш символ не разделитель
            if (s.length < i || s[i + 1] !== ' ') {
                res += ' ';
            }
        }
    }
    return res;
}

//3)4. Оставить в строке только один экземпляр каждого встречающегося символа.
function removeRepeatedSymbols(s) {
    res = '';
    for (var i = 0; i < s.length; i++) {
        if (res.indexOf(s[i]) === -1) {
            res += s[i];
        }
    }
    return res;
}

//3)5. Подсчитать количество слов во введенной пользователем строке.
function countWords (s) {
    var wordsArray = splitWordsBySymbols(s);
    return wordsArray.length;
    function splitWordsBySymbols(s) {//разделяет строку по знакам препинания и пробелам
        var ref = '!.,;? ';
        var buffer = '';
        var res = [];
        for (var i = 0; i < s.length; i++) {
            if (ref.indexOf(s[i]) === -1) {//наш символ не разделитель
                buffer += s[i];//отправили символ в буффер
            } else {
                if (buffer !== '') {
                    res.push(buffer);
                    buffer = '';
                }
            }
        }
        if (buffer !== '') {
            res.push(buffer);
        }
        return res;
    }
}

//3)6. Удалить из строки ее часть с заданной позиции и заданной длины.
function splice (s, start, len) {
    var part1 = s.slice(0, start);
    var part2 = s.slice(start + len);
    return part1 + part2;
}

//3)7. Перевернуть строку, т.е. последние символы должны стать первыми, а первые последними.
function reverseString(s){
    var res = '';
    for(var i=s.length-1; i>=0; i--){
        res += s[i];
    }
    return res;
}

//3)8. В заданной строке удалить последнее слово
function deleteString(s) {
    var res = splitWordsBySymbolsAndSeparators(s);
    for (var i = res.length - 1; i >= 0; i--) {
        if (res[i].type === 'word') {
            res.splice(i, 1);
            break;
        }
    }
    var resStr = '';
    for (var i = 0; i < res.length; i++) {
        resStr += res[i].content;
    }
    return resStr;
    //разделяет строку по знакам препинания и пробелам
    //не убирая знаки препинания и пробелы
    function splitWordsBySymbolsAndSeparators(s) {
        var ref = '!.,;? ';
        var buffer = '';
        var separatorBuffer = '';
        var res = [];
        for (var i = 0; i < s.length; i++) {
            if (ref.indexOf(s[i]) === -1) {//наш символ не разделитель
                buffer += s[i];//отправили символ в буфер
                if (separatorBuffer !== '') {
                    res.push({type: 'separator', content: separatorBuffer});
                    separatorBuffer = '';
                }
            } else {
                separatorBuffer += s[i];
                if (buffer !== '') {
                    res.push({type: 'word', content: buffer});
                    buffer = '';
                }
            }
        }
        if (buffer !== '') {
            res.push({type: 'word', content: buffer});
        }
        if (separatorBuffer !== '') {
            res.push({type: 'separator', content: separatorBuffer});
        }
        return res;
    }
}
