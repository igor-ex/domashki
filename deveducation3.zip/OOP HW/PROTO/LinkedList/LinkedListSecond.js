function LinkedListSecond() {

    ListFirst.apply(this, arguments);

    this.root = null;
    this.last = null;
    this.length = 0;

}

LinkedListSecond.prototype = Object.create(ListSecond.prototype);
LinkedListSecond.prototype.constructor = LinkedListSecond;

LinkedListSecond.prototype.pushSingle = function (val) {
    const e = new Entry(val);
    if (this.last) {
        this.last.next = e;
        e.prev = this.last;
    } else {
        this.root = e;
    }
    this.last = e;
    this.length++;
    return this.length;
};

LinkedListSecond.prototype.unshiftSingle = function (val) {
    const e = new Entry(val);
    if (this.root) {
        this.root.prev = e;
        e.next = this.root;
    } else {
        this.last = e;
    }
    this.root = e;
    this.length++;
    return this.length;
};

LinkedListSecond.prototype.push = function (val) {
    if (!arguments.length) {
        return this.length;
    }
    for (let i = 0; i < arguments.length; i++) {
        this.pushSingle(arguments[i])
    }
    return this.length;
};

LinkedListSecond.prototype.unshift = function (val) {
    if (!arguments.length) {
        return this.length;
    }
    for (let i = arguments.length-1; i >= 0; i--) {
        this.unshiftSingle(arguments[i])
    }
    return this.length;
};

LinkedListSecond.prototype.pop = function () {
    if (!this.last) {
        return;
    }
    const e = this.last;
    const currentLast = e.prev;
    if (currentLast) {
        this.last = currentLast;
        currentLast.next = null;
    } else {
        this.last = null;
        this.root = null
    }
    this.length--;
    return e.val;
};

LinkedListSecond.prototype.shift = function () {
    if (!this.root) {
        return;
    }
    const e = this.root;
    const newRoot = e.next;
    if (newRoot) {
        this.root = newRoot;
        newRoot.prev = null;
    } else {
        this.root = null;
        this.last = null;
    }
    this.length--;
    return e.val;
};

LinkedListSecond.prototype.isArray = function () {
    return true;
};

LinkedListSecond.prototype.some = function(func) {
    if (!this.length) {
        return false;
    }
    let current = this.root;
    do {
        if (func(current.val) === true) {
            return true;
        }
    } while (current = current.next);
    return false;
};

LinkedListSecond.prototype.every = function(func) {
    if (!this.length) {
        return false;
    }
    let current = this.root;
    do {
        if (func(current.val) === false) {
            return false;
        }
    } while (current = current.next);
    return true;
};

LinkedListSecond.prototype.iterate = function(func) {
    if (!this.length) {
        return;
    }
    let current = this.root;
    do {
        func(current.val);
    } while (current = current.next)
};

LinkedListSecond.prototype.remove = function(ind) {
    if (ind > this.length - 1) {
        return void 0;
    }
    let current = this.root;
    for (let i = 0; i < ind; i++) {
        current = current.next;
    }
    const prev = current.prev;
    const next = current.next;
    if (prev) {
        if (next) {
            prev.next = next;
        } else {
            prev.next = null;
        }
    } else {
        if (next) {
            this.root = next;
        } else {
            this.root = null;
        }
    }
    if (next) {
        if (prev) {
            next.prev = prev;
        } else {
            next.prev = null;
        }
    } else {
        if (prev) {
            this.last = prev;
        } else {
            this.last = null;
        }
    }

    this.length--;
    return current.val;
};

LinkedListSecond.prototype.sort = function (func) {
    if (!this.root || !this.root.next) {
        return this;
    }

    function traverse(cur) {//возвращает элемент с максимальным значением начиная с cur
        let max = cur;
        do {
            if ((typeof func === 'function' && func(cur.val, max.val) > 0) || cur.val > max.val) {
                max = cur;
            }
        } while (cur = cur.next);
        return max;
    }

    const getIndex = function (e) {//возвращает индекс элемента
        let cur = this.root;
        let counter = 0;
        do {
            if (cur === e) {
                return counter;
            }
            counter++;
        } while (cur = cur.next);
    }.bind(this);

    let max = traverse(this.root);
    if (max !== this.root) {
        this.unshift(this.remove(getIndex(max)));
    }
    let cur = this.root.next;
    do {
        max = traverse(cur);
        if (max === cur) {
            cur = cur.next;//когда за cur не останется элементов, ему присвоится null
        }
        this.unshift(this.remove(getIndex(max)));
    } while (cur);

    return this;
};

LinkedListSecond.prototype.toString = function () {
    let s = '';
    let current = this.root;
    if (!current) {
        return s;
    }
    do {
        s += current.val.toString();
        if (current.next) {
            s += ', ';
        }
    } while (current = current.next);
    return s;
};

LinkedListSecond.prototype.toArrayList = function() {
    const aList = new ArrayList;
    let current = this.root;
    if (!current) {
        return aList;
    }
    do {
        aList.push(current.val);
    } while (current = current.next);

    return aList;
}


function Entry(val) {
    this.val = val;
    this.prev = null;
    this.next = null;
}



