
function ListFirst() {}

ListFirst.prototype.push = function () {};

ListFirst.prototype.pop = function () {};

ListFirst.prototype.shift = function () {};

ListFirst.prototype.unshift = function () {};

ListFirst.prototype.isArray = function () {};

ListFirst.prototype.some = function () {};

ListFirst.prototype.every = function () {};

ListFirst.prototype.remove = function () {};

ListFirst.prototype.splice = function () {};