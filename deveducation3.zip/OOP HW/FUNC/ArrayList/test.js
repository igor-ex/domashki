
describe('ArrayListSecond', function () {


    describe('ArrayListSecond', function () {

        const arr = new ArrayListSecond();

        it('should have several specific methods and length property', function () {
            assert.isFunction(arr.push);
            assert.isFunction(arr.pop);
            assert.isFunction(arr.shift);
            assert.isFunction(arr.isArray);
            assert.isFunction(arr.some);
            assert.isFunction(arr.every);
            assert.isFunction(arr.remove);
            assert.isFunction(arr.splice);
            assert.isFunction(arr.toString);
            assert.isFunction(arr.toLinkedList);
            assert.isFunction(arr.sort);
            assert.isNumber(arr.length);
            assert.isArray(arr.arr);
        });
    });

    describe('sort', function () {
        const testData = [
            {init: [], exp: []},
            {init: [1], exp: [1]},
            {init: [1, 2], exp: [1, 2]},
            {init: [2, 1], exp: [1, 2]},
            {init: [5, 4, 3, 2, 1], exp: [1, 2, 3, 4, 5]},
            {init: [0, 1, 2, 3, 0], exp: [0, 0, 1, 2, 3]},
            {init: [72, 7, 1, 0, 7, 2, 473, 19465], exp: [0, 1, 2, 7, 7, 72, 473, 19465]},
        ];
        testData.forEach(function (data) {
            const {init, exp} = data;
            const arr = new ArrayListSecond;
            arr.push.apply(arr, init);
            arr.sort(function (a, b) {
                if (a < b) {
                    return -1;
                } else if (a > b) {
                    return 1;
                } else {
                    return 0;
                }
            });
            ex(arr.arr, 'arr test sort');
            it(`should sort elements`, function () {
                assert.deepEqual(arr.arr, exp);
            })
        })
    });

    describe('toString', function () {
        //given
        const testData = [
            {arr: [0, 1, 2], exp: '0, 1, 2'},
            {arr: [6, -1, 5], exp: '6, -1, 5'},
            {arr: [-1, 5], exp: '-1, 5'},
            {arr: [5, 'hello', 0], exp: '5, hello, 0'},
            {arr: [-5], exp: '-5'},
            {arr: [], exp: ''},
        ];
        testData.forEach(function (data) {
            const {arr, exp} = data;
            const obj = new ArrayListSecond;
            obj.push.apply(obj, arr);

            it(`should return a string`, function () {
                //when
                const act = obj.toString();
                //then
                assert.strictEqual(act, exp, `returned: ${act}, data: ${arr}`);
            })
        })
    });

    describe('toLinkedList', function () {
        //given
        const testData = [
            [1, 2, 3],
            [1],
            []
        ];
        testData.forEach(function (data) {
            const obj = new ArrayListSecond;
            obj.push.apply(obj, data);

            it(`should return the same data`, function () {
                //when
                const act = obj.toLinkedList();
                //then
                const l = new LinkedList;
                l.push.apply(l, data);
                assert.deepEqual(act, l, `returned: ${act}, data: ${data}`);
            });
        });
    });


});