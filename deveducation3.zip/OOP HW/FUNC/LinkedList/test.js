
describe('LinkedListSecond', function () {

    const arr = new LinkedListSecond();

    it('should have several specific methods and length property', function () {
        assert.isFunction(arr.push);
        assert.isFunction(arr.pop);
        assert.isFunction(arr.shift);
        assert.isFunction(arr.isArray);
        assert.isFunction(arr.some);
        assert.isFunction(arr.every);
        assert.isFunction(arr.remove);
        assert.isFunction(arr.splice);
        assert.isFunction(arr.toString);
        assert.isFunction(arr.toArrayList);
        assert.isFunction(arr.sort);
        assert.isNumber(arr.length);
        assert.isNull(arr.root);
        assert.isNull(arr.last);
    });
});

describe('LinkedListSecond.toArrayList', function () {
    //given
    const testData = [
        [1, 2, 3],
        [1],
        []
    ];
    testData.forEach(function (data) {
        const obj = new LinkedListSecond;
        obj.push.apply(obj, data);

        it(`should return the same data`, function () {
            //when
            const act = obj.toArrayList();
            //then
            const actEls = [];
            for (let i = 0; i < obj.length; i++) {
                actEls.push(getLListEl.call(obj, i));
            }
            assert.deepEqual(actEls, data, `returned: ${act}, data: ${data}`);
        })
    })
});

describe('.LinkedListSecond.toString', function () {
    //given
    const testData = [
        {arr: [0, 1, 2], exp: '0, 1, 2'},
        {arr: [6, -1, 5], exp: '6, -1, 5'},
        {arr: [-1, 5], exp: '-1, 5'},
        {arr: [5, 'hello', 0], exp: '5, hello, 0'},
        {arr: [-5], exp: '-5'},
        {arr: [], exp: ''},
    ];
    testData.forEach(function (data) {
        const {arr, exp} = data;
        const obj = new LinkedListSecond;
        obj.push.apply(obj, arr);

        it(`should return a string`, function () {
            //when
            const act = obj.toString();
            //then
            assert.strictEqual(act, exp, `returned: ${act}, data: ${arr}`);
        })
    })
});

describe('LinkedListSecond.sort', function () {
    const testData = [
        {init: [], exp: []},
        {init: [1], exp: [1]},
        {init: [1, 2], exp: [1, 2]},
        {init: [2, 1], exp: [1, 2]},
        {init: [5, 4, 3, 2, 1], exp: [1, 2, 3, 4, 5]},
        {init: [0, 1, 2, 3, 0], exp: [0, 0, 1, 2, 3]},
        {init: [72, 7, 1, 0, 7, 2, 473, 19465], exp: [0, 1, 2, 7, 7, 72, 473, 19465]},
    ];
    testData.forEach(function (data) {
        const {init, exp} = data;
        const arr = new LinkedListSecond;
        arr.push.apply(arr, init);
        arr.sort(function (a, b) {
            if (a < b) {
                return -1;
            } else if (a > b) {
                return 1;
            } else {
                return 0;
            }
        });
        ex(arr.arr, 'arr test sort');
        it(`should sort elements`, function () {
            const actEls = [];
            for (let i = 0; i < arr.length; i++) {
                actEls.push(getLListEl.call(arr, i));
            }
            assert.deepEqual(actEls, exp);
        })
    })
});

function getLListEl (ind) {
    if (ind > this.length-1) {
        return void 0;
    }
    let current = this.root;
    for (let i = 0; i < ind; i++) {
        current = current.next;
    }
    return current.val;
}