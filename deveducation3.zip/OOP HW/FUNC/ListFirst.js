
function ListFirst() {
    this.push = function () {};
    
    this.pop = function () {};
    
    this.shift = function () {};
    
    this.unshift = function () {};
    
    this.isArray = function () {};
    
    this.some = function () {};
    
    this.every = function () {};
    
    this.remove = function () {};
    
    this.splice = function () {};
}

