function ListSecond() {
    ListFirst.apply(this);

    this.sort = function() {

    }

    this.toString = function () {

    }

    this.toArrayList = function () {

    }

    this.toLinkedList = function () {

    }
}

ListSecond.prototype = Object.create(ListFirst.prototype);
ListSecond.prototype.constructor = ListSecond;