function Programmer(age, name) {
    this.age = age;
    this.name = name;
    this._CONSTANT_ID = 1;
}
Programmer.prototype.toString = function (){
        return this.age + ' ' + this.CONSTANT_ID;
};
Programmer.prototype.getName = function (){
    return this.name;
};
Programmer.prototype.setAge = function (value){
    this.age = value;
};


function JunProgrammer() {
    Programmer.apply(this, arguments);
    this.level = 'junior';
}

JunProgrammer.prototype = Object.create(Programmer.prototype);
JunProgrammer.prototype.constructor = JunProgrammer;

JunProgrammer.prototype.toString = function () {
    return this.age + ' ' + this.name + ' ' + this.level;
};
JunProgrammer.prototype.setAge = function (value) {
    Programmer.prototype.setAge.apply(this, [value]);
    this.age = this.age + 8;
};


programmerFirst = new JunProgrammer(15, 'Jony');



