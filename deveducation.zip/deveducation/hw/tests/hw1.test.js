describe('multiplyOrSum', function(){
    it('should', function() {
        //given
        const a = 1;
        const b = 2;
        const expected = 3;

        //when
        const actual = multiplyOrSum(a, b);

        //then
        assert.equal(actual, expected);
    });
});