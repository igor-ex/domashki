describe('multiplyOrSum', function () {
   it('should return a + b', function () {
      const a = 1;
      const b = 2;
      const expected = 3;

      const actual = multiplyOrSum(a, b);

       assert.equal(actual, expected);
   });

   it('should return a * b', function () {
       const a = 2;
       const b = 3;
       const expected = 6;

       const actual = multiplyOrSum(a, b);

       assert.equal(actual, expected);
   })
});

describe('getQuarterByCoordinates', function() {
    it('should return 2', function() {
        const x = -1;
        const y = 1;
        const expected = 2;
        const actual = getQuarterByCoordinates(x, y);

        assert.strictEqual(actual, expected);

    })
})

describe('throw error when point is on axis', function() {
        const testData = [
            {x: 0, y: 1},
            {x: 1, y: 2}
        ]
});

describe('getPositiveNumbersSum', function() {
    describe('returns sum of positive numbers', function() {
        const testData = [
            {a:1, b: -1, c: 0, expected: 1},
        ]

        testData.forEach(function(data) {
            const {a, b, c, expected} = data;

            it(`should return ${expected} when a = ${a}.....`, function() {
                const actual = getPositiveNumbers(a, b, c);

                assert.strictEqual(actual, expected);
            })
        });
    })
})
/*
describe('calculateMaxSumOrMultiplyPlusThree', function() {//1
    describe('returns max of a + b + c or a + b + s plus 3', function() {//2
        const testData = [
            {a:0, b:1, c:2, expected: 3},
        ];

        testData.forEach(function (data) {//3
            it('should...',function() {//4
                const {a, b, c, expectd} = data;//деструктуризация

                const actual = calcul;
            });//4)
            
        });//3)
    });//2)
});//1)


describe('thows error when is out of range', function() {
    const testData = [
        {-1, -100, 101, 200}
    ];
    testData.forEach(function(rating){
        it('should ....', function(){
            const actual = fu(rating);
            assert.strictEqual(actual, expected);
        });
        it('should thow error',function(){
            assert.throw(function(){

            });
        })

    }
})

*/
describe('getMinArrEl', function () {
    describe('returns min element from array', function() {
        const testData = [
            { array: [], expected: null },
        ];
        testData.forEach(function(data){
            const {array, expected} = data;
            it(`should return ${expected} if array is ${array}`, function(){
                const actual = getMinArrEl(array);

                assert.strictEqual(actual, expected);
            })
        }
        )
    })
})